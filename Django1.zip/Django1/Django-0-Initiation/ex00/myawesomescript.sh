# Check if the user has provided an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <bit.ly-url>"
  exit 1
fi

# Use curl to get headers, follow redirects (-L), and then use grep to extract the Location header
curl -sIL "$1" | grep -i Location | cut -d ' ' -f2