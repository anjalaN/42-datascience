from django.shortcuts import render

def cv_view(request):
    return render(request, 'ex04/snippets.html')
