from django.apps import AppConfig


class Ex04Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ex04'
