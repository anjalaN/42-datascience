from django.shortcuts import render

def cv_view(request):
    return render(request, 'ex03/copy.html')
