from django.apps import AppConfig


class Ex03Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ex03'
