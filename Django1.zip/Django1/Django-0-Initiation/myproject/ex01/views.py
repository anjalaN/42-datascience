from django.shortcuts import render

def cv_view(request):
    return render(request, 'ex01/cv.html')

def home(request):
    return render(request, 'home.html')
