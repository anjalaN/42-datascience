from django.shortcuts import render

def cv_view(request):
    return render(request, 'ex05/index.html')
