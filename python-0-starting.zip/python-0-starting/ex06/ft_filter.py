#!/usr/bin/env python3
#!/usr/bin/env python3
import sys



def ft_filter(function, iterable):
      
    if function is None:
        return (item for item in iterable if item)
    return (item for item in iterable if function(item))

# Exemple d'utilisation
def is_even(n):
    return n % 2 == 0

numbers = [1, 2, 3, 4, 5, 6]
filtered_numbers = ft_filter(is_even, numbers)
print(list(filtered_numbers))  

