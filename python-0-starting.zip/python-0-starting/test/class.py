#!/usr/bin/env python3
#testing differant functionprit()
# def greet(name):
#     return f"hello world"
# print(greet("Alice")) 

# add = lambda x, y: x + y
# print(add(2, 3))

# def factorial(n):
#     if n == 0:
#         return 1
#     else:
#         return n * factorial(n - 1)
    
# print(factorial(5))
# def outer_function():
#     def inner_function():
#         return "Hello from inside!"
#     return inner_function()

# print(outer_function())  # Prints "Hello from inside!"

try:
    x = 1
    y = 0
    assert y != 0, "invalide operation"
    print(x/y)

except AssertionError as smg:
    print(smg)