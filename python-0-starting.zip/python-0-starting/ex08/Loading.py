#!/use/bin/env python3
def ft_tqdm(lst: range) -> None
