#!/usr/bin/env python3
from NULL_not_found import NULL_not_found

Nothing = None
Garlic = float("Nan")
Zero = 0
Empty = ''
Fake = False

NULL_not_found(Nothing)
NULL_not_found(Garlic)
NULL_not_found(Zero)
NULL_not_found(Empty)
NULL_not_found(Fake)
print(NULL_not_found("Brian"))



# from NULL_not_found import NULL_not_found

# Nothing = None
# Cheese = float("nan")
# Zero = 0
# Empty = ''
# Fake = False

# print(NULL_not_found(Nothing))
# print(NULL_not_found(Cheese))
# print(NULL_not_found(Zero))
# print(NULL_not_found(Empty))
# print(NULL_not_found(Fake))
# print(NULL_not_found("Brian"))
