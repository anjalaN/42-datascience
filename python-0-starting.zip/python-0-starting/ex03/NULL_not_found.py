#!/usr/bin/env python3

def NULL_not_found(object: any) -> any:

    if object is None:
        print(f"Nothing: None {type(object)}")
        return 0
    
    elif isinstance(object, float) and object != object:
        print(f"Cheese: nan {type(object)}")
        return 0
    
    elif object is False:
        print(f"Fake: False {type(object)}")
        return 0
    elif object == 0:
        print(f"Zero: 0 {type(object)}")
        return 0
    
    elif object == '':
        print(f"Empty: {type(object)}")
        return 0
   
    else:
        print("Type not Found$")
        return 1
      


