from typing import Any


def ft_statistics(*args: Any, **kwargs: Any) -> None:
    try:
        # Check if all *args are numeric
        if not args or not all(isinstance(arg, (int, float)) for arg in args):
            # raise ValueError("All *args must be numeric!")
            raise ValueError()
        # Sort the data for calculating quartiles
        data = sorted(args)

        # Compute required statistics
        mean = sum(data) / len(data)
        mid = len(data) // 2
        median = (
            data[mid] if len(data) % 2 != 0  # Odd length:
            else (data[mid - 1] + data[mid]) / 2
        )
        quartile_25 = float(data[len(data) // 4])
        quartile_75 = float(data[(3 * len(data)) // 4])
        std = (sum((x - mean) ** 2 for x in data) / len(data)) ** 0.5
        var = sum((x - mean) ** 2 for x in data) / len(data)
        # Process **kwargs for specific statistics
        for key, value in kwargs.items():
            if value == "mean":
                print(f"mean : {mean}")
            elif value == "median":
                print(f"median : {median}")
            elif value == "quartile":
                print(f"quartile : [{quartile_25}, {quartile_75}]")
            elif value == "std":
                print(f"Std: {std}")
            elif value == "var":
                print(f"Var: {var}")
            else:
                print("ERROR")
    except ValueError:
        print("ERROR")
    except Exception:
        print("ERROR")
