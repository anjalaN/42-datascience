#!/usr/bin/env python3

# function to calculate the square of a number
def square(x: int | float) -> int | float:
    """
    function for square
    """
    return x * x


# function to calculate the exponentiation of a number by itself
def pow(x: int | float) -> int | float:
    """
    Compute the square of number

    Args:
        x (iny | float): the number to be sqared.
    Returns:
        int | float: The sure of the input number
    """
    return x ** x


# Function to calculatte the exponentiation of a number by itself
def outer(x: int | float, function) -> object:
    """
    Outer function that takes a number and a function,
    and return an inner function
    Compute the exponentiation of a number by itself (x^x).

    Args:
        x (int | float): Initial value to compute on.
        function (function): The function to apply to the value.

    Returns:
        object: The inner function that computes the result when called.
    """
    value = x  # start with the initial value of x

    def inner() -> float:
        """
        inner function that computes the result of given function

        Returns:
            float: The update value after applying the function
        """
        nonlocal value  # allow modification of 'value' in the outer scope
        value = function(value)  # Apply the function to the current value
        return value
    return inner  # Return the inner function
