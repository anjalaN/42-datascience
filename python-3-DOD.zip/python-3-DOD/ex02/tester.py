#!/usr/bin/env python3
# from callLimit import callLimit

# @callLimit(3)
# def f():
#     print ("f()")

# @callLimit(1)
# def g():
#     print ("g()")

# for i in range(3):
#     #print(f"Attempt {i +1}:")
#     f()
#     g()
#     #Sprint("---")

from callLimit import callLimit


@callLimit(3)
def f():
    print("f()")


@callLimit(1)
def g():
    print("g()")


for i in range(3):
    f()
    g()
