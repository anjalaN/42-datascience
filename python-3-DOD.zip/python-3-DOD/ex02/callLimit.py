#!/usr/bin/env python3

from typing import Callable, Any


def callLimit(limit: int) -> Callable:
    """
    Decorator that restricts the number of times a function can be called.

    Args:
        limit (int): The maximum number of times the function can be called.

    Returns:
        Callable: A wrapper function that enforces the call limit.
    """
    def callLimiter(function: Callable) -> Callable:
        count = 0  # Counter how many times the function has been called

        def limit_function(*args: Any, **kwargs: Any) -> Any:
            nonlocal count  # Refers to the counter in the enclosing scope
            if count < limit:
                count += 1
                return function(*args, **kwargs)
            else:
                print(f"Error: {function} call to many times")
                return None  # Block further calls

        return limit_function

    return callLimiter
