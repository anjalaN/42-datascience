#!/usr/bin/env python3

from new_student import Student
student = Student(name="Edward", surname="agle")
print(student)

# from new_student import Student

# # Attempt to create a Student instance with an 'id' argument
# try:
#     student = Student(name="Edward", surname="agle", id="toto")
#     print(student)
# except TypeError as e:
#     print(e)
