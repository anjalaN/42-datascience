#!/usr/bin/env python3

class calculator:
    """
    Calculator class for vector operations.
    """

    @staticmethod
    def dotproduct(v1: list[float], v2: list[float]) -> float:
        """
        Calculate the dot product of two vectors.
        :param v1: First vector (list of numbers)
        :param v2: Second vector (list of numbers)
        :return: dot product (number)
        """
        result = sum(x * y for x, y in zip(v1, v2))
        print(f"Dot product is: {result}")  # Print statement added
        return result

    @staticmethod
    def add_vec(v1: list[float], v2: list[float]) -> list[float]:
        """
        Add two vectors element-wise.
        :param v1: First vector (list of numbers)
        :param v2: Second vector (list of numbers)
        :return: Resultant vector (list of numbers)
        """
        result = [float(x + y) for x, y in zip(v1, v2)]
        print(f"Add Vector is : {result}")  # Print statement added
        return result

    @staticmethod
    def sous_vec(v1: list[float], v2: list[float]) -> list[float]:
        """
        Subtract the second vector from the first element-wise.
        :param v1: First vector (list of numbers)
        :param v2: Second vector (list of numbers)
        :return: Resultant vector (list of numbers)
        """
        result = [float(x - y) for x, y in zip(v1, v2)]
        print(f"Sous Vector is: {result}")  # Print statement added
        return result
