from abc import ABC, abstractmethod


# Abstract base class
class Character(ABC):
    """
    Abstract class representing a character with
    a first name and a health state.
    """

    def __init__(self, first_name: str, is_alive: bool = True):
        """
        Initialize a character with a first name and health state.

        Args:
            first_name (str): The character's first name.
            is_alive (bool): The health state of the character.
            Default is True.
        """
        self.first_name = first_name
        self.is_alive = is_alive

    @abstractmethod
    def change_health_state(self):
        """
        Abstract method to change the health state of the character.
        """
        pass

    def die(self):
        """
        Set the character's health state to dead
        by calling change_health_state().
        """
        self.change_health_state()


class Stark(Character):
    """
    Subclass representing a Stark character.
    """

    def change_health_state(self):
        """
        Change the health state from alive to dead.
        """
        self.is_alive = False

    def die(self):
        """
        Set the character's health state to dead.
        """
        self.change_health_state()


def main():
    """
    Main function for testing the Character and Stark classes.
    """
    try:
        # Test creating an instance of Character (should raise an error)
        try:
            Character("Generic")  # This should fail
        except TypeError as e:
            print(f"Error: {e}")

        # Test creating an instance of Stark
        stark_char = Stark("Arya")
        print(
            f"Character: {stark_char.first_name}, "
            f"Is Alive: {stark_char.is_alive}"
            )

        # Test changing health state
        stark_char.die()
        print(
            f"Character: {stark_char.first_name}, "
            f"Is Alive: {stark_char.is_alive}"
            )

    except Exception as e:
        print(f"Unhandled Exception: {e}")


if __name__ == "__main__":
    main()
