# from S1E9 import Character, Stark

# Test cases for Stark
# Ned = Stark("Ned")
# print(Ned.__dict__)            # {'first_name': 'Ned', 'is_alive': True}
# print(Ned.is_alive)            # True
# Ned.die()                      # Change health state
# print(Ned.is_alive)            # False
# print(Ned.__doc__)             # Your docstring for Class
# print(Ned.__init__.__doc__)    # Your docstring for Constructor
# print(Ned.die.__doc__)         # Your docstring for Method
# print("---")
# Lyanna = Stark("Lyanna", False)
# print(Lyanna.__dict__)         # {'first_name': 'Lyanna', 'is_alive': False}


# from S1E9 import Character

# try:
#     hodor = Character("hodor")
# except TypeError as e:
#     print(f"TypeError: {e}")
