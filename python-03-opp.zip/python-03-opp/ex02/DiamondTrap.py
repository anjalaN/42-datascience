#!/usr/bin/env python3
from S1E7 import Baratheon, Lannister


class King(Baratheon, Lannister):
    """
    King class inherits characteristics of both Baratheon and Lannister.
    """

    def __init__(self, first_name, is_alive=True):
        """
        Initialize a King with the default characteristics,
        inheriting from both Baratheon and Lannister.

        Args:
            first_name (str): The first name of the King.
            is_alive (bool): The health state of the King. Default is True.
        """
        # Initialize both parent classes
        super().__init__(first_name, is_alive)

    def set_eyes(self, color: str):
        """
        Set the eye color of the King.

        Args:
            color (str): The color to set for the eyes.
        """
        self.eyes = color

    def get_eyes(self) -> str:
        """
        Get the eye color of the King.

        Returns:
            str: The current eye color.
        """
        return self.eyes

    def set_hairs(self, color: str):
        """
        Set the hair color of the King.

        Args:
            color (str): The color to set for the hairs.
        """
        self.hairs = color

    def get_hairs(self) -> str:
        """
        Get the hair color of the King.

        Returns:
            str: The current hair color.
        """
        return self.hairs
