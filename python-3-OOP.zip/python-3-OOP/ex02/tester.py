
from DiamondTrap import King

# Create an instance of King
Joffrey = King("Joffrey")
print(Joffrey.__dict__)  # Display the attributes of the King instance

# Set eye and hair colors
Joffrey.set_eyes("blue")
Joffrey.set_hairs("light")

# Get eye and hair colors
print(Joffrey.get_eyes())  # Expected output: blue
print(Joffrey.get_hairs())  # Expected output: light

# Display updated attributes
print(Joffrey.__dict__)  # Updated attributes should now include eyes and hairs
