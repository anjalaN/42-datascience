#!/usr/bin/env python3

class Calculator:
    """
    Calculator with add, multiply, subtract, and division operations.
    """

    def __init__(self, vector):
        """
        Initialize the calculator with a vector.

        :param vector: list of numerical values
        """
        self.vector = vector

    def __mul__(self, object) -> None:
        """
        Multiply each element of the vector by the scalar.

        :param object: scalar value for multiplication
        """
        self.vector = [x * object for x in self.vector]

    def __add__(self, object) -> None:
        """
        Add scalar to each element of the vector.
        :param object: scalar value for addition
        """
        self.vector = [x + object for x in self.vector]

    def __sub__(self, object) -> None:
        """
        Subtract scalar from each element of the vector.

        :param object: scalar value for subtraction
        """
        self.vector = [x - object for x in self.vector]

    def __truediv__(self, object) -> None:
        """
        Divide each element of the vector by the scalar.

        :param object: scalar value for division
        :raises ZeroDivisionError: if the scalar is zero
        """
        if object == 0:
            raise ZeroDivisionError("Cannot divide by zero.")
        self.vector = [x / object for x in self.vector]

    def __repr__(self) -> str:
        """
        Represent the vector in a readable format.

        :return: string representation of the vector
        """
        return f"{self.vector}"
