#!/user/bin/env python3

from ft_calculator import Calculator

v1 = Calculator([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])
v1 + 5
print(v1)
print("---")
v2 = Calculator([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])
v2 * 5
print(v2)
print("---")
v3 = Calculator([10.0, 15.0, 20.0])
v3 - 5
print(v3)
v3 / 5
print(v3)
