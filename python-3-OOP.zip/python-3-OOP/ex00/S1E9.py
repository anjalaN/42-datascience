from abc import ABC, abstractmethod


class Character(ABC):
    """
    Abstract class representing a character with
    a first name and a health state.
    """
    def __init__(self, first_name, is_alive=True):
        """
        My docstring for Constructor: Initialize
        a character with a first name and health state.
        Args:
            first_name (str): The character's first name.
            is_alive (bool): The health state of
            the character. Default is True.
        """
        if type(self) is Character:
            raise TypeError(
                "Can't instantiate abstract class "
                "Character with abstract method"
            )
        self.first_name = first_name
        self.is_alive = is_alive

    @abstractmethod
    def change_health_state(self):
        """
        Abstract method to change the health state of the character.
        """
        pass


# Subclass: Stark
class Stark(Character):
    """
    My docstring for class: representing a Stark character.
    """
    def change_health_state(self):
        """
        Change the health state from alive to dead.
        """
        self.is_alive = False

    def die(self):
        """
        My doctring for Methord: Set the character's health state to dead.
        """
        self.change_health_state()
