#!/usr/bin/env python3

from S1E7 import Baratheon, Lannister

# Test the Baratheon class
Robert = Baratheon("Robert")
print(Robert.__dict__)  # Check attributes of the instance
print(Robert.__str__)   # Check string method
print(Robert.__repr__)  # Check repr method
print(Robert.is_alive)  # Check initial health state
Robert.die()            # Set health state to "dead"
print(Robert.is_alive)  # Check updated health state
print(Baratheon.__doc__)  # Display docstring for the class
print("---")

# Test the Lannister class
Cersei = Lannister("Cersei")
print(Cersei.__dict__)  # Check attributes of the instance
print(Cersei.__str__)   # Check string method
print(Cersei.is_alive)  # Check initial health state
print("---")

# Test the factory method for the Lannister class
jaime = Lannister.create_lannister("Jaine", True)
print(
    f"Name : ('{jaime.first_name}', '{jaime.family_name}'), "
    f"Alive : {jaime.is_alive}"
    )
