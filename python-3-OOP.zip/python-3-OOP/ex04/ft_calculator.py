# #!/usr/bin/env python3
# class calculator:
#     """
#     A calculator class for vector operations.
#     """

#     def __init__(self, vector):
#         """
#         Initialize the calculator with a vector.
#         :param vector: A list of numerical values.
#         """
#         self.vector = vector

#     # Additional methods for add, subtract, etc., would follow
#     def __add__(self, value):
#         self.vector = [x + value for x in self.vector]

#     def __mul__(self, value):
#         self.vector = [x * value for x in self.vector]

#     def __sub__(self, value):
#         self.vector = [x - value for x in self.vector]

#     def __truediv__(self, value):
#         if value == 0:
#             raise ZeroDivisionError("Division by zero is not allowed.")
#         self.vector = [x / value for x in self.vector]

#     def __repr__(self):
#         return f"{self.vector}"


class calculator:
    """
    calculator class for vector operation
    """

    # decorator for dotproduct methord
    @staticmethod
    def dotproduct(v1: list[float], v2: list[float]) -> float:
        """
        calculate the dot product of two vectors
        :param vec1: First vector (list of the numbers)
        :param vec2: Second vector (list of numbers)
        :return: dot product (number)
        """
        return sum(x * y for x, y in zip(v1, v2))
    # Decorator for add_vec method

    @staticmethod
    def add_vec(v1: list[float], v2: list[float]) -> list[float]:
        """
        Add two vectors element-wise
        :param vec1: First vector (list of the numbers)
        :param vec2: Second vector (list of numbers)
        :return: Resultant vector (list of number)
        """
        return [x + y for x, y in zip(v1, v2)]

    # Decorator for sous_vec method
    @staticmethod
    def sous_vec(v1: list[float], v2: list[float]) -> list[float]:
        """
        subtract the secon vector from the first element-wise
        :param vec1: First vector (list of the numbers)
        :param vec2: Second vector (list of numbers)
        :return: Resultant vector (list of number)
        """
        return [x - y for x, y in zip(v1, v2)]
