#!/user/bin/env python3
from ft_calculator import calculator

a = [5, 10, 2]
b = [2, 4, 3]
print("Dot Product:", calculator.dotproduct(a, b))
print("Addition of Vectors:", calculator.add_vec(a, b))
print("Substract of vectors:", calculator.sous_vec(a, b))
